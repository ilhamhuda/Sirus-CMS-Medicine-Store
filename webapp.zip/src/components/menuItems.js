export default {
  items: [
    { icon: 'all_inclusive', text: 'Order', href: '#/order' },
    { icon: 'find_in_page', text: 'Transaction', href: '#/transaction' },
    { icon: 'view_list', text: 'Product', href: '#/product' }
  ]
}
